package mk.ukim.finki.np.av1;

/**
 * Homework 1.1 Roman converter
 */
public class RomanConverter {
    /**
     * Roman to decimal converter
     *
     * @param n number in decimal format
     * @return string representation of the number in Roman numeral
     */
    public static String toRoman(int n) {
        // your solution here
        return "";
    }

    public static void main(String[] args) {
        System.out.println(RomanConverter.toRoman(1998));
    }
}
