package mk.ukim.finki.np.av1;

/**
 * Homework 1.2 number printer
 */
public class NumberPrinter {

    /**
     * Print numbers from 1 to howMany in following format [1][2]...[howMany]
     *
     * @param howMany    how many numbers to print
     * @param lineLength the length of the lin
     */
    public static void formatNumbers(int howMany, int lineLength) {
        // your solution here
    }

    public static void main(String[] args) {
        formatNumbers(250, 60);
    }
}
