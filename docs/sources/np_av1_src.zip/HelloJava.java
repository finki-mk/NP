package mk.ukim.finki.np.av1;

/**
 * Hello world, hello Java, hello Napredno Programiranje
 */
public class HelloJava {
    public static void main(String[] args) {
        System.out.println("Hello Java");
    }
}
