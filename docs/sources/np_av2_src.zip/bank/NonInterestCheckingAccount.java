package mk.ukim.finki.np.av2.bank;

public class NonInterestCheckingAccount extends Account {

    public NonInterestCheckingAccount(String holderName, int number, double currentAmount) {
        super(holderName, number, currentAmount);
    }

}
