package mk.ukim.finki.np.av2.bank;

public interface InterestBearingAccount {
    void addInterest();
}
