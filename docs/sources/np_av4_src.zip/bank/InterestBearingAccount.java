package mk.ukim.finki.np.av4.bank;

public interface InterestBearingAccount {
    void addInterest();
}
